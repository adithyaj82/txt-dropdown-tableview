//
//  ViewController.swift
//  JOSNSwiftDemo
//
//  Created by Shinkangsan on 12/5/16.
//  Copyright © 2016 Sheldon. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITableViewDataSource,UITableViewDelegate ,UITextFieldDelegate{

    @IBOutlet var txt: NoCopyPasteUITextField!
    @IBOutlet var hideview: UIView!
    //@IBOutlet var txt: NoCopyPasteUITextField!
    final let urlString = "http://mbdbtechnology.com/projects/buildster/ws/webservice/get_country"
    
    @IBOutlet weak var tableView: UITableView!
    
    var nameArray = [String]()
    var dobArray = [String]()
    var imgURLArray = [String]()
    
    @IBAction func textFieldChanged(_ sender: AnyObject) {
        hideview.isHidden = true
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?)
    {
        guard let touch:UITouch = touches.first else
        {
            return;
        }
        if touch.view != tableView
        {
            txt.endEditing(true)
            hideview.isHidden = true
        }
    }
    
    // Toggle the tableView visibility when click on textField
    func textFieldActive() {
        hideview.isHidden = !hideview.isHidden
    }
    
    // MARK: UITextFieldDelegate
    func textFieldDidEndEditing(_ textField: UITextField) {
        // TODO: Your app can do something when textField finishes editing
        print("The textField ended editing. Do something based on app requirements.")
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        txt.resignFirstResponder()
        return true
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        hideview.isHidden = true
       txt.addTarget(self, action: #selector(textFieldActive), for: UIControlEvents.touchDown)
        txt.delegate = self

        self.downloadJsonWithURL()
        
        // Do any additional setup after loading the view, typically from a nib.
    }
    @IBAction func closePopUp(_ sender: AnyObject) {
      hideview.isHidden = true
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
   
    
    func downloadJsonWithURL() {
        let url = NSURL(string: urlString)
        URLSession.shared.dataTask(with: (url as? URL)!, completionHandler: {(data, response, error) -> Void in
            
            if let jsonObj = try? JSONSerialization.jsonObject(with: data!, options: .allowFragments) as? NSDictionary {
                
                if let actorArray = jsonObj!.value(forKey: "country_data") as? NSArray {
                    for actor in actorArray{
                        if let actorDict = actor as? NSDictionary {
                            if let name = actorDict.value(forKey: "nicename") {
                                self.nameArray.append(name as! String)
                            }
//                            if let name = actorDict.value(forKey: "dob") {
//                                self.dobArray.append(name as! String)
//                            }
//                            if let name = actorDict.value(forKey: "image") {
//                                self.imgURLArray.append(name as! String)
//                            }
                            
                        }
                    }
                }
                
                OperationQueue.main.addOperation({
                    self.tableView.reloadData()
                })
            }
        }).resume()
    }

    
    func downloadJsonWithTask() {
        
        let url = NSURL(string: urlString)
        
        var downloadTask = URLRequest(url: (url as? URL)!, cachePolicy: URLRequest.CachePolicy.reloadIgnoringCacheData, timeoutInterval: 20)
        
        downloadTask.httpMethod = "GET"
        
        URLSession.shared.dataTask(with: downloadTask, completionHandler: {(data, response, error) -> Void in
            
            let jsonData = try? JSONSerialization.jsonObject(with: data!, options: .allowFragments)
            
            
        }).resume()
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return nameArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell") as! TableViewCell
        cell.nameLabel.text = nameArray[indexPath.row]
     //   cell.dobLabel.text = dobArray[indexPath.row]
        
//        let imgURL = NSURL(string: imgURLArray[indexPath.row])
//
//        if imgURL != nil {
//            let data = NSData(contentsOf: (imgURL as? URL)!)
//            cell.imgView.image = UIImage(data: data as! Data)
//        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        

        txt.text = nameArray[indexPath.row]
        hideview.isHidden = true
      //  tableView.isHidden = true
      //  txt.endEditing(true)
    }
//    func textFieldActive() {
//        tableView.isHidden = !tableView.isHidden
//    }
//    
//    // MARK: UITextFieldDelegate
//    func textFieldDidEndEditing(_ textField: UITextField) {
//        // TODO: Your app can do something when textField finishes editing
//        print("The textField ended editing. Do something based on app requirements.")
//    }
//    
//    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
//        textField.resignFirstResponder()
//        return true
//    }
//    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?)
//    {
//        guard let touch:UITouch = touches.first else
//        {
//            return;
//        }
//        if touch.view != tableView
//        {
//            txt.endEditing(true)
//            tableView.isHidden = true
//        }
//    }
    ///for showing next detailed screen with the downloaded info
    
}

